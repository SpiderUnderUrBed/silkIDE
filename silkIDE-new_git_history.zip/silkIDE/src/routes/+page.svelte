<script>
	import { Routes } from '$lib/config';
	import Greet from '$lib/components/Greet.svelte';
</script>

<a href={Routes.IDE}>Go to IDE</a>

<Greet />
