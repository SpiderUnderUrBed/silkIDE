<script>
	import '$css/app.css';
	import '$css/global.css';
</script>

<slot />
