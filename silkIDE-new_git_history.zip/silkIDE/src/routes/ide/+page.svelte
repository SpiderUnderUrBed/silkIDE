<main>
	<div class="container">
		<div class="file-explorer">
			<div class="header-file-explorer">
				<center><p>File Explorer:</p></center>
			</div>
			<div class="files-folders-handler">
				<!-- ADD THE FILE ORGANIZER STUFF HERE @SPIDER -->
			</div>
		</div>
		<div class="csharp-edit">
			<div>
				<!-- MAKE SURE TO ADD THE VERTICAL LINE LIKE IN VSCODE -->
				<textarea class="edit"></textarea>
			</div>
		</div>
	</div>
</main>
