<script>
	import '$css/ide.css';
</script>

<slot />
