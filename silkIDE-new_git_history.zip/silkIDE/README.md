<p align="center">
  <img src="static/Icon.png" width=128 alt="silk-ide-logo" />
</p>

# Silk IDE

- Text editor for **C#**.

## Tools

| Tools              | Availability |
| ------------------ | ------------ |
| Syntax Highlighter | &check;      |
| Code Formatter     | &check;      |
| Code Runner        | in progress  |
| Example Generator  | &cross;      |
